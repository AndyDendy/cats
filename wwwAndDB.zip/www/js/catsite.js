var arr=window.location.href.split("/");
var dom_name=arr[0]+"//"+arr[2];

var wsUri = "ws://"+arr[2]+":500/",
        websocket = new WebSocket(wsUri);
		
websocket.onopen = function (e) {
        websocket.send(document.cookie);
    };
	    websocket.onmessage = function (e) {
			document.getElementById("butlist").innerHTML = "";
		document.getElementById("butlist").innerHTML = e.data;
    };
	 websocket.onclose = function (e) {
        
    };
var id='';
function butF(e){
	id=e;
}

document.onload = function(){
	
	document.getElementById("sendbut").addEventListener("click", Presend());
};




function Presend(){
	websocket.send(document.cookie.split('=','!')[1]+"!"+id+"!"+document.getElementById("send").value);
};

function onDragEnd() {
var lngLat = marker.getLngLat();
document.getElementById("lat").value=lngLat.lat;
document.getElementById("lon").value=lngLat.lng;
}
