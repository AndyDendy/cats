var arr=window.location.href.split("/");
var dom_name=arr[0]+"//"+arr[2];

function LogIn() {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
	window.location.href=dom_name+"/catsite.html";
    }
  };
  var name=document.getElementById("msg").value, par=document.getElementById("password").value;
  
  xhttp.open("POST", dom_name+"/login", true);
  xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xhttp.send(name+"!"+par);
}

function SignUp() {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
	window.location.href=this.responseText;
    }
  };
  var name=document.getElementById("login").value, par=document.getElementById("password").value;
  xhttp.open("POST", dom_name+"/sign_up", true);
  xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xhttp.send(name+"!"+par);
}
function onDragEnd() {
var lngLat = marker.getLngLat();
document.getElementById("lat").value=lngLat.lat;
document.getElementById("lon").value=lngLat.lng;
}
